package com.simple.stock.market.simplestockmarket;

public enum StockType {
	COMMON, PREFERRED
}
