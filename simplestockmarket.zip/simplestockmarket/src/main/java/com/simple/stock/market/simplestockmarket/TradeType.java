package com.simple.stock.market.simplestockmarket;

public enum TradeType {
	BUY, SELL
}
