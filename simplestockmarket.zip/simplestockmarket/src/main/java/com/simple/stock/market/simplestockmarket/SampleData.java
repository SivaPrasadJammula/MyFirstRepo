package com.simple.stock.market.simplestockmarket;

import java.util.HashMap;
import java.util.Map;

import org.springframework.context.annotation.Bean;

public class SampleData {

	@Bean
	Map<String, GbceData> Db() {
		HashMap<String, GbceData> db = new HashMap<String, GbceData>();
		db.put("TEA", new GbceData("TEA", StockType.COMMON, 0.0, 0.0, 100.0));
		db.put("POP", new GbceData("POP", StockType.COMMON, 8.0, 0.0, 100.0));
		db.put("ALE", new GbceData("ALE", StockType.COMMON, 23.0, 0.0, 60.0));
		db.put("GIN", new GbceData("GIN", StockType.PREFERRED, 8.0, 0.2, 100.0));
		db.put("JOE", new GbceData("JOE", StockType.COMMON, 13.0, 0.0, 250.0));
		return db;
	}
}
