package com.simple.stock.market.simplestockmarket;

import java.util.Date;
import java.util.SortedMap;
import java.util.TreeMap;

public class GbceData {

	private String stockSymbol;
	private StockType stockType;
	private Double lastDividend;
	private Double fixedDividend;
	private Double parValue;
	private TreeMap<Date, Trade> trades;

	public Double calVolumeWeighStckPrice() {
		Date now = new Date();
		Date startTime = new Date(now.getTime() - (15 * 60 * 1000));
		SortedMap<Date, Trade> trades = this.trades.tailMap(startTime);
		Double volumeWeigtStckPrice = 0.0;
		Integer totalQuantity = 0;
		for (Trade trade : trades.values()) {
			totalQuantity += trade.getQuantity();
			volumeWeigtStckPrice += trade.getPrice() * trade.getQuantity();
		}
		return volumeWeigtStckPrice / totalQuantity;
	}

	public GbceData(String stockSymbol, StockType type, Double lastDividend, Double fixedDividend, Double parValue) {
		this.setStockSymbol(stockSymbol);
		this.setType(type);
		this.setLastDividend(lastDividend);
		this.setFixedDividend(fixedDividend);
		this.setParValue(parValue);
		this.trades = new TreeMap<Date, Trade>();
	}

	public String getStockSymbol() {
		return stockSymbol;
	}

	public void setStockSymbol(String stockSymbol) {
		this.stockSymbol = stockSymbol;
	}

	@Override
	public String toString() {
		return "Stock [stockSymbol=" + stockSymbol + ", stockType=" + stockType + ", lastDividend=" + lastDividend
				+ ", fixedDividend=" + fixedDividend + ", parValue=" + parValue + "]";
	}

	public Double dividend(Double price) {
		switch (this.getStockType()) {
		case COMMON:
			return this.getLastDividend() / price;
		case PREFERRED:
			return this.getFixedDividend() * this.getParValue() / price;
		default:
			return 0.0;
		}
	}

	public Double peRatio(Double price) {
		return price / this.getLastDividend();
	}

	public void buy(Integer quantity, Double price) {
		Trade trade = new Trade(TradeType.BUY, quantity, price);
		this.trades.put(new Date(), trade);
	}

	public void sell(Integer quantity, Double price) {
		Trade trade = new Trade(TradeType.SELL, quantity, price);
		this.trades.put(new Date(), trade);
	}

	public Double getPrice() {
		if (this.trades.size() > 0) {
			return this.trades.lastEntry().getValue().getPrice();
		} else {
			return 0.0;
		}
	}

	public StockType getStockType() {
		return stockType;
	}

	public void setType(StockType stockType) {
		this.stockType = stockType;
	}

	public Double getLastDividend() {
		return lastDividend;
	}

	public void setLastDividend(Double lastDividend) {
		this.lastDividend = lastDividend;
	}

	public Double getFixedDividend() {
		return fixedDividend;
	}

	public void setFixedDividend(Double fixedDividend) {
		this.fixedDividend = fixedDividend;
	}

	public Double getParValue() {
		return parValue;
	}

	public void setParValue(Double parValue) {
		this.parValue = parValue;
	}

	public TreeMap<Date, Trade> getTrades() {
		return trades;
	}

	public void setTrades(TreeMap<Date, Trade> trades) {
		this.trades = trades;
	}

}
