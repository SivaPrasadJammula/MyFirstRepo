package com.simple.stock.market.simplestockmarket;

import java.util.Map;

public class AllShareIndex {

	public static Double allShareIndex(Map<String, GbceData> stocks) {

		Double allShareIndex = 0.0;

		for (GbceData stock : stocks.values()) {
			allShareIndex += stock.getPrice();
		}
		return Math.pow(allShareIndex, 1.0 / stocks.size());
	}

}
