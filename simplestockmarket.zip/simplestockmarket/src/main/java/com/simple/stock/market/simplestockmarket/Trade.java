package com.simple.stock.market.simplestockmarket;

public class Trade {
	private TradeType tradeType;
	private Integer quantity;
	private Double price;

	public TradeType getTradeType() {
		return tradeType;
	}

	public void setTradeType(TradeType tradeType) {
		this.tradeType = tradeType;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	public Trade(TradeType tradeType, Integer quantity, Double price) {
		super();
		this.tradeType = tradeType;
		this.quantity = quantity;
		this.price = price;
	}

	@Override
	public String toString() {
		return "TradeMarket [type=" + tradeType + ", quantity=" + quantity + ", price=" + price + "]";
	}

}
