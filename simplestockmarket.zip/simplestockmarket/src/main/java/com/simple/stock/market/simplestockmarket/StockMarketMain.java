package com.simple.stock.market.simplestockmarket;

import java.util.Map;
import java.util.Random;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

/**
 * Stock Market
 *
 */
public class StockMarketMain {
	private static Log log = LogFactory.getLog(StockMarketMain.class);

	public static void main(String[] args) {
		try {

			@SuppressWarnings("resource")
			ApplicationContext context = new AnnotationConfigApplicationContext(SampleData.class);

			@SuppressWarnings("unchecked")
			Map<String, GbceData> db = context.getBean("Db", Map.class);
			for (GbceData stock : db.values()) {
				System.out.println(stock.getStockSymbol() + " Dividend: " + stock.dividend(9.1));
				System.out.println(stock.getStockSymbol() + " P/E Ratio: " + stock.peRatio(9.1));

				for (int i = 1; i <= 10; i++) {
					Random r = new Random();
					Integer rangeMin = 1;
					Integer rangeMax = 10;
					double randomValue = rangeMin + (rangeMax - rangeMin) * r.nextDouble();
					stock.buy(i, randomValue);
					System.out.println(stock.getStockSymbol() + " Bought " + i + " Shares at £" + randomValue);
					randomValue = rangeMin + (rangeMax - rangeMin) * r.nextDouble();
					stock.sell(i, randomValue);
					System.out.println(stock.getStockSymbol() + " Sold " + i + " Shares at £" + randomValue);
					Thread.sleep(1000);
				}
				System.out.println(stock.getStockSymbol() + " Price: £" + stock.getPrice());
				System.out.println(
						stock.getStockSymbol() + " VolumeWeightedStockPrice: £" + stock.calVolumeWeighStckPrice());
			}
			AllShareIndex.allShareIndex(db);

		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
	}
}
