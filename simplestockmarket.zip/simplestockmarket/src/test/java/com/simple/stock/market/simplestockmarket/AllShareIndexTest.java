package com.simple.stock.market.simplestockmarket;

import static org.junit.Assert.assertEquals;

import java.util.HashMap;

import org.junit.Test;

public class AllShareIndexTest {
	@Test
	public void testAllShareIndex() {
        HashMap<String, GbceData> db = new HashMap<String, GbceData>();
        db.put("TEA", new GbceData("TEA", StockType.COMMON, 0.0, 0.0, 100.0));
        db.put("POP", new GbceData("POP", StockType.COMMON, 8.0, 0.0, 100.0));
        db.put("ALE", new GbceData("ALE", StockType.COMMON, 23.0, 0.0, 60.0));
        db.put("GIN", new GbceData("GIN", StockType.PREFERRED, 8.0, 0.2, 100.0));
        db.put("JOE", new GbceData("JOE", StockType.COMMON, 13.0, 0.0, 250.0));
        
        for (GbceData stock: db.values()) {
            // Record some trades
        	for (int i=1; i <= 10; i++) {
        		stock.buy(1, 1.0);
        		stock.sell(1, 1.0);
        	}
        }
        Double GBCEallShareIndex = AllShareIndex.allShareIndex(db);
        assertEquals(1.379729661461215, GBCEallShareIndex, 0.0);
	}
}
